// Point2D.java: Class for points in logical coordinates.
// Contains 3D object data
export  class Point2D
{
    x: number; y: number;
    constructor (x:number, y:number){this.x = x; this.y = y;}
}